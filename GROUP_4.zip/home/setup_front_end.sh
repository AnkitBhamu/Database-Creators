#! /bin/bash
pip install flask
pip install psycopg2-binary
