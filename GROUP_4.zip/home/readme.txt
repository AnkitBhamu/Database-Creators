we just used the the password and the username as  provided in the mail by ta
